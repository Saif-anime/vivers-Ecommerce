from django.db import models
import datetime
# Create your models here.

class Banner(models.Model):
    banner_img = models.ImageField(upload_to='banner', blank=True)
    date_issued = models.DateField(default = datetime.date.today())
    banner_category = models.CharField(max_length = 200, default="")

    def __str__(self):
        return self.banner_category
