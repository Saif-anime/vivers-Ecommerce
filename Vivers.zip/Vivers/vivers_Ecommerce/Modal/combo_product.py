from django.db import models
import datetime

# Create your models here.

class Combo_Product(models.Model):
    product_name = models.CharField(max_length = 200, default="")
    product_actual_price = models.IntegerField(default=0)
    product_offer_price = models.IntegerField(default=0)
    product_disc = models.TextField(max_length = 1000, default="")
    product_img = models.ImageField(upload_to='combo', blank=True)
    date_issued = models.DateField(default = datetime.date.today())

    def __str__(self):
        return self.product_name
