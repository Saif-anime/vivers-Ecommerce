from django.db import models
import datetime
# Create your models here.

class DemoStream(models.Model):
    thum_img = models.ImageField(upload_to='video_thumb', blank=True)
    Video = models.FileField(upload_to='video', blank=True)
    title = models.CharField(max_length = 200, default="")
    date_issued = models.DateField(default = datetime.date.today())
    video_category = models.CharField(max_length = 200, default="")
    

    def __str__(self):
        return self.title
