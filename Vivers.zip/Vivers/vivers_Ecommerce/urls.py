from django.urls import path

from . import views


urlpatterns = [
    path("", views.index, name="index"),
    path('product_page/<int:pro_id>', views.single_product, name='single_product'),
    path('cart', views.cart, name='cart'),
    path('Emailing_Sending', views.Emailing_Sending, name='Emailing_Sending'),
    path('checkout', views.checkout, name='checkout'),
    path('products/<str:cate>', views.products, name='products'),
    path('Switch_To_b2b', views.switch_to_b2b, name='switch_to_b2b'),
    path('streaming_video', views.streaming_video, name='streaming_video'),
    path("handlerequest/", views.handlerequest, name="HandleRequest"),

    path("error", views.Error_page, name="Error_Page"),
]