from django.shortcuts import render
from django.http import HttpResponse
from .Modal.product import Product
from .Modal.banner import Banner
from .Modal.combo_product import Combo_Product
from .Modal.DemoStream import DemoStream
from .Modal.Order import Orders
from .Modal.OrderUpdate import OrderUpdate
import ffmpeg_streaming
from django.views.decorators.csrf import csrf_exempt
from paytm import Checksum

from django.conf import settings
from django.core.mail import send_mail


MERCHANT_KEY = 'kbzk1DSbJiV_03p5'


# Create your views here.


def index(request):

    data = [1,2,3,4]
    d = Product.objects.all()[0:4]
    c = Combo_Product.objects.all()[0:4]
    seafood = Product.objects.filter(product_category = 'Seafood')
    category = set()

    for x in d:
        category.add(x)
    print(category)
    banner = Banner.objects.all()

    print(banner)
    return render(request, "index.html", {'data':data, 'p':d, 'banner':banner, 'category':category, 'combo':c, 'Seafood':seafood})

def Emailing_Sending(request):
    subject = 'welcome to GFG world'
    message = f'Hi , thank you for registering in geeksforgeeks.'
    email_from = [settings.EMAIL_HOST_USER]
    recipient_list = ['nisha828784@gmail.com']
    send_mail( subject, message, email_from, recipient_list, fail_silently=False )
    pass

def single_product(request, pro_id):
    d = Product.objects.all()
    category = set()

    for x in d:
        category.add(x)


    d = Product.objects.filter(id=pro_id).all()
    cate = d.values_list('product_category')[0][0]
    
    data = Product.objects.filter(product_category = cate)
    return render(request, 'Single_product.html', {'data':data, 'pro':d,  'category':category})

def products(request, cate):
    search = request.GET.get('search')
    d = Product.objects.all()
    category = set()

    for x in d:
        category.add(x)

    if search is None:
        if cate == "all":
            p = Product.objects.all()
        else:
            p = Product.objects.filter(product_category = cate)
    elif search == 'combo':
        p = Combo_Product.objects.all()
    else:
        p = Product.objects.filter(product_category = search)
    
    return render(request, "Products.html" , {'p':p,  'category':category, 'cate':cate, })

def cart(request):
    d = Product.objects.all()
    category = set()

    for x in d:
        category.add(x)
    return render(request, "cart.html", { 'category':category})

def checkout(request):
    d = Product.objects.all()
    category = set()

    for x in d:
        category.add(x)
    
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        item_json = request.POST.get('order_json')
        amount = request.POST.get('total_input')
        phone = request.POST.get('phone')
        billing_address  = request.POST.get('billing-address')
        state = request.POST.get('billing-state')
        zip_code = request.POST.get('billing-zip')

        order = Orders(items_json = item_json, amount = amount, name=name, email = email, address=billing_address, city = state, state = state, zip_code = zip_code, phone= phone)
        order.save()
        update = OrderUpdate(order_id = order.order_id, update_desc="The order has been placed")
        update.save()

        param_dict={

            'MID': 'ZBSqqX05890285114272',
            'ORDER_ID': str(order.order_id),
            'TXN_AMOUNT': str(amount),
            'CUST_ID': email,
            'INDUSTRY_TYPE_ID': 'Retail',
            'WEBSITE': 'WEBSTAGING',
            'CHANNEL_ID': 'WEB',
            'CALLBACK_URL':'http://127.0.0.1:8000/handlerequest/',
            }
        param_dict['CHECKSUMHASH'] = Checksum.generate_checksum(param_dict, MERCHANT_KEY)
        print(param_dict)
        return render(request, 'paytm.html', {'param_dict': param_dict})
    return render(request, "checkout.html", { 'category':category})



@csrf_exempt
def handlerequest(request):
    checksum = ""
    # paytm will send you post request here
    form = request.POST
    response_dict = {}
    for i in form.keys():
        response_dict[i] = form[i]
        if i == 'CHECKSUMHASH':
            checksum = form[i]
    print(checksum)

    verify = Checksum.verify_checksum(response_dict, MERCHANT_KEY, checksum)
    print(verify)
    
    if verify:
        if response_dict['RESPCODE'] == '01':
            print('order successful')
        else:
            print('order was not successful because' + response_dict['RESPMSG'])
    return render(request, 'paymentstatus.html', {'response': response_dict})

def switch_to_b2b(request):
    d = Product.objects.all()
    category = set()

    for x in d:
        category.add(x)

    return render(request, 'Switch_to_B2b.html', { 'category':category})




def streaming_video(request):
    v = DemoStream.objects.all()
    for x in v:
        video = ffmpeg_streaming.input(x.Video)
    return render(request, 'streaming_video.html', {'video':video})

def Error_page(request):
    return render(request, '404_page.html')