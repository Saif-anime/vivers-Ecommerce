from django.contrib import admin

# Register your models here.
from .Modal.product import Product
from .Modal.banner import Banner
from .Modal.combo_product import Combo_Product
from .Modal.DemoStream import DemoStream
from .Modal.Order import Orders
from .Modal.OrderUpdate import OrderUpdate

admin.site.register(Product)
admin.site.register(Banner)
admin.site.register(Combo_Product)
admin.site.register(DemoStream)
admin.site.register(Orders)
admin.site.register(OrderUpdate)